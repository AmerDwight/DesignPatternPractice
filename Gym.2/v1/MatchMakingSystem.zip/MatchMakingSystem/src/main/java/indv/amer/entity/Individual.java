package indv.amer.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class Individual {

    /**
     * 性別 (Gender) 的列舉類型
     */
    public enum Gender {
        MALE,
        FEMALE
    }

    private int id; // 編號 (ID)
    private Gender gender; // 性別 (Gender)
    private int age; // 年紀 (Age)
    private String intro; // 自我介紹 (Intro)
    private List<String> habits; // 興趣 (Habits)
    private Coord coord; // 座標 (Coord)

    /**
     * Constructor for Individual class.
     *
     * @param id           編號 (ID)，必須是正整數 (>0) 且每位對象的編號都不同。
     * @param gender       性別 (Gender)，使用 Gender 列舉 (MALE 或 FEMALE)。
     * @param age          年紀 (Age)，必須是正整數且至少 18 歲。
     * @param intro        自我介紹 (Intro)，長度約 0~200 的文字。
     * @param habitsString 興趣 (Habits) 的字串，每個興趣以逗號隔開，每個興趣長度 1~10。 例如："打籃球, 煮菜, 玩遊戲"
     * @param coord        座標 (Coord) 物件，表示用戶所在的 x 軸和 y 軸的位置。
     * @throws IllegalArgumentException 如果輸入參數不符合條件 (thrown by setters).
     */
    public Individual(int id, Gender gender, int age, String intro, String habitsString, Coord coord) {
        setId(id);
        setGender(gender);
        setAge(age);
        setIntro(intro);
        setHabits(habitsString);
        setCoord(coord);
    }


    // Helper method to parse habits string into a list of habits (remains the same)
    private List<String> parseHabits(String habitsString) {
        List<String> habitList = new ArrayList<>();
        String[] habitsArray = habitsString.split(",");
        for (String habit : habitsArray) {
            String trimmedHabit = habit.trim(); // 去除前後空白
            if (!trimmedHabit.isEmpty()) {
                if (trimmedHabit.length() > 10) {
                    throw new IllegalArgumentException("每個興趣 (Habit) 長度必須在 1~10 字之間: '" + trimmedHabit + "'");
                }
                habitList.add(trimmedHabit);
            }
        }
        return habitList;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true; // 如果是同一個物件實例，直接返回 true
        if (obj == null || getClass() != obj.getClass()) return false; // 檢查是否為 null 或不同類別

        Individual that = (Individual) obj; // 將 obj 強制轉型為 Individual 物件

        // 逐個比較所有屬性
        if (id != that.id) return false;
        if (age != that.age) return false;
        if (gender != that.gender) return false; // Enum 可以直接使用 == 比較
        if (!Objects.equals(intro, that.intro)) return false; // String 使用 Objects.equals 處理 null 情況
        if (!Objects.equals(habits, that.habits)) return false; // List 使用 Objects.equals 比較列表內容
        return Objects.equals(coord, that.coord); // Coord 物件也需要有自己的 equals 方法
    }


    // --- Setters with Constraints ---

    public void setId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("編號 (ID) 必須是正整數 (>0)");
        }
        this.id = id;
    }

    public void setGender(Gender gender) {
        if (gender == null) {
            throw new IllegalArgumentException("性別 (Gender) 不能為空"); // Optional null check if gender is mandatory
        }
        this.gender = gender;
    }

    public void setAge(int age) {
        if (age < 18) {
            throw new IllegalArgumentException("年紀 (Age) 必須至少 18 歲");
        }
        this.age = age;
    }

    public void setIntro(String intro) {
        if (intro != null && intro.length() > 200) {
            throw new IllegalArgumentException("自我介紹 (Intro) 長度不能超過 200 字");
        }
        this.intro = intro;
    }

    public void setHabits(String habitsString) {
        if (habitsString != null) {
            this.habits = parseHabits(habitsString);
        } else {
            this.habits = new ArrayList<>();
        }
    }

    public void setCoord(Coord coord) {
        if (coord == null) {
            throw new IllegalArgumentException("座標 (Coord) 不能為空"); // Optional null check if coord is mandatory
        }
        this.coord = coord;
    }


    // --- Getters ---

    public int getId() {
        return id;
    }

    public Gender getGender() {
        return gender;
    }

    public int getAge() {
        return age;
    }

    public String getIntro() {
        return intro;
    }

    public List<String> getHabits() {
        return habits;
    }

    public Coord getCoord() {
        return coord;
    }


    @Override
    public String toString() {
        return "Individual{" +
                "id=" + id +
                ", gender=" + gender +
                ", age=" + age +
                ", intro='" + intro + '\'' +
                ", habits=" + habits +
                ", coord=" + coord +
                '}';
    }
}
