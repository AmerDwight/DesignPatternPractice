package indv.amer.strategy;

import indv.amer.entity.Individual;
import org.apache.commons.collections4.CollectionUtils;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;

public class HabitBasedStrategy extends MatchingStrategy {
    @Override
    public Individual matching(Individual seeker, Collection<Individual> targetGroup) {
        List<Individual> groupWithoutSeeker = this.peopleExcludeSeeker(seeker, targetGroup)
                .stream().distinct().sorted(Comparator.comparingInt(Individual::getId)).toList();

        Individual bestMatcher = groupWithoutSeeker.stream().findFirst().orElseThrow();
        int mostSameHabits = calculateSameHabitNumber(seeker,bestMatcher);

        for (Individual indv : groupWithoutSeeker) {
            int sameHabitNumber = calculateSameHabitNumber(seeker,indv);
            // 只有在相同興趣更多才換，相當數量時會保證最小編號
            if (sameHabitNumber > mostSameHabits) {
                bestMatcher = indv;
                mostSameHabits = sameHabitNumber;
            }
        }
        return bestMatcher;
    }

    @Override
    public Individual reverseMatching(Individual seeker, Collection<Individual> targetGroup) {
        List<Individual> groupWithoutSeeker = this.peopleExcludeSeeker(seeker, targetGroup)
                .stream().distinct().sorted(Comparator.comparingInt(Individual::getId)).toList();

        Individual bestMatcher = groupWithoutSeeker.stream().findFirst().orElseThrow();
        int leastSameHabits = calculateSameHabitNumber(seeker,bestMatcher);

        for (Individual indv : groupWithoutSeeker) {
            int sameHabitNumber = calculateSameHabitNumber(seeker,indv);
            // 只有在相同興趣更少才換，相當數量時會保證最小編號
            if (sameHabitNumber < leastSameHabits) {
                bestMatcher = indv;
                leastSameHabits = sameHabitNumber;
            }
        }
        return bestMatcher;
    }

    private int calculateSameHabitNumber(Individual a, Individual b) {
        if (CollectionUtils.isEmpty(a.getHabits()) || CollectionUtils.isEmpty(b.getHabits())) {
            return 0;
        }
        return CollectionUtils.intersection(a.getHabits(), b.getHabits()).size();
    }

}
