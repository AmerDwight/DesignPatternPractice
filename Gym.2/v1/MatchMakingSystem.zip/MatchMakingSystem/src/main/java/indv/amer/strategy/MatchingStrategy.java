package indv.amer.strategy;

import indv.amer.entity.Individual;

import java.util.Collection;
import java.util.stream.Collectors;

public abstract class MatchingStrategy {
    public abstract Individual matching(Individual seeker, Collection<Individual> targetGroup);

    public abstract Individual reverseMatching(Individual seeker, Collection<Individual> targetGroup);

    Collection<Individual> peopleExcludeSeeker(Individual seeker, Collection<Individual> people) {
        return people.stream().filter(
                individual -> !individual.equals(seeker)).collect(Collectors.toSet());
    }
}
