package indv.amer;

import indv.amer.entity.Individual;
import indv.amer.strategy.DistanceBasedStrategy;
import indv.amer.strategy.HabitBasedStrategy;
import indv.amer.strategy.MatchingStrategy;

import java.util.Collection;
import java.util.Random;

public class MatchMakingSystem extends VirtualEnvironment {

    public MatchingStrategy strategy;

    public Collection<Individual> people;

    public MatchMakingSystem(MatchingStrategy _strategy) {
        this.strategy = _strategy;
    }

    public static void main(String[] args) {
        MatchMakingSystem habitBasedSystem = new MatchMakingSystem(new HabitBasedStrategy());
        MatchMakingSystem distanceBasedSystem = new MatchMakingSystem(new DistanceBasedStrategy());

        // Initializing
        habitBasedSystem.init();
        distanceBasedSystem.init();

        // Start Matching
        for (Individual seeker : habitBasedSystem.people) {

            boolean seekerIsNormalGuy = randomDiceForTrueFalse();
            Individual bestMatch;
            if (seekerIsNormalGuy) {
                bestMatch = habitBasedSystem.strategy.matching(seeker, habitBasedSystem.people);
            } else {
                bestMatch = habitBasedSystem.strategy.reverseMatching(seeker, habitBasedSystem.people);
            }
            writeMessage("For ID: " + seeker.getId() + " Best Match is ID: " + bestMatch.getId() +
                    " Seeker: " + seeker + ";" +
                    " BestMatch: " + bestMatch);
        }
        for (Individual seeker : distanceBasedSystem.people) {

            boolean seekerIsNormalGuy = randomDiceForTrueFalse();
            Individual bestMatch;
            if (seekerIsNormalGuy) {
                bestMatch = distanceBasedSystem.strategy.matching(seeker, distanceBasedSystem.people);
            } else {
                bestMatch = distanceBasedSystem.strategy.reverseMatching(seeker, distanceBasedSystem.people);
            }
            writeMessage("For ID: " + seeker.getId() + " Best Match is ID: " + bestMatch.getId() +
                    " Seeker: " + seeker + ";" +
                    " BestMatch: " + bestMatch);
        }
    }

    public void init() {
        this.init(100);
    }

    public void init(int peopleAmount) {
        this.people = this.createSampleIndividuals(peopleAmount);
    }

    private static void writeMessage(String message) {
        System.out.println(message);
    }

    private static boolean randomDiceForTrueFalse() {
        Random random = new Random();
        // 只會有 0/ 1
        return random.nextInt(2) == 0;
    }
}
