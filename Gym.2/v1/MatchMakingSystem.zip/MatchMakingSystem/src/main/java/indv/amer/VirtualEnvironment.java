package indv.amer;


import indv.amer.entity.Coord;
import indv.amer.entity.Individual;

import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

/**
 * For Easier Demo
 */
public class VirtualEnvironment{
    /**
     * Creates a set of sample Individual objects.
     * This method is moved from the Individual class to the VirtualEnvironment class.
     *
     * @param numberOfIndividuals The number of sample individuals to create.
     * @return A Set of Individual objects.
     */
    public Collection<Individual> createSampleIndividuals(int numberOfIndividuals) {
        Set<Individual> individuals = new HashSet<>();
        java.util.Random random = new java.util.Random();
        int idCounter = 1; // To ensure unique IDs

        // Sample data lists for variety (moved here for VirtualEnvironment context if needed)
        java.util.List<Individual.Gender> genders = java.util.Arrays.asList(Individual.Gender.MALE, Individual.Gender.FEMALE);
        java.util.List<String> sampleIntros = java.util.Arrays.asList(
                "喜歡程式和旅行",
                "熱愛閱讀和烹飪",
                "享受戶外活動",
                "沉迷於音樂和電影",
                "美食愛好者",
                "一個簡單的人",
                "積極向上",
                "夢想家",
                "探索者",
                "" // Empty intro
        );
        java.util.List<String> sampleHabitsLists = java.util.Arrays.asList(
                "程式, 旅行",
                "閱讀, 烹飪",
                "登山, 游泳, 跑步",
                "音樂, 電影, 戲劇",
                "美食, 烹飪, 烘焙",
                "寫作",
                "繪畫, 攝影",
                "學習新事物",
                "社交, 聚會",
                "" // No habits
        );

        for (int i = 0; i < numberOfIndividuals; i++) {
            int id = idCounter++;
            Individual.Gender gender = genders.get(random.nextInt(genders.size()));
            int age = 18 + random.nextInt(60); // Ages from 18 to 77 (18 + 59)
            String intro = sampleIntros.get(random.nextInt(sampleIntros.size()));
            String habitsString = sampleHabitsLists.get(random.nextInt(sampleHabitsLists.size()));
            int xCoord = random.nextInt(200) - 100; // x from -100 to 99
            int yCoord = random.nextInt(200) - 100; // y from -100 to 99
            Coord coord = new Coord(xCoord, yCoord);

            Individual individual = new Individual(id, gender, age, intro, habitsString, coord);
            individuals.add(individual); // Set ensures uniqueness based on equals/hashCode if implemented, or ID in this case by default
        }
        return individuals.stream().sorted(Comparator.comparingInt(Individual::getId)).toList();
    }
}
