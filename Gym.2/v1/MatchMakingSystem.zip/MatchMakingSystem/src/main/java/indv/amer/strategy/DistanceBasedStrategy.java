package indv.amer.strategy;

import indv.amer.entity.Individual;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;

public class DistanceBasedStrategy extends MatchingStrategy {
    @Override
    public Individual matching(Individual seeker, Collection<Individual> targetGroup) {
        List<Individual> groupWithoutSeeker = this.peopleExcludeSeeker(seeker, targetGroup)
                .stream().distinct().sorted(Comparator.comparingInt(Individual::getId)).toList();

        Individual bestMatcher = groupWithoutSeeker.stream().findFirst().orElseThrow();
        float lowestDistance = seeker.getCoord().calculateDistance(bestMatcher.getCoord());

        for (Individual indv : groupWithoutSeeker) {
            float newDistance = seeker.getCoord().calculateDistance(indv.getCoord());
            // 只有在距離較小才換，相當距離時會保證最小編號
            if (newDistance < lowestDistance) {
                bestMatcher = indv;
                lowestDistance = newDistance;
            }
        }
        return bestMatcher;
    }

    @Override
    public Individual reverseMatching(Individual seeker, Collection<Individual> targetGroup) {
        List<Individual> groupWithoutSeeker = this.peopleExcludeSeeker(seeker, targetGroup)
                .stream().distinct().sorted(Comparator.comparingInt(Individual::getId)).toList();
        Individual bestMatcher = groupWithoutSeeker.stream().findFirst().orElseThrow();
        float largestDistance = seeker.getCoord().calculateDistance(bestMatcher.getCoord());

        for (Individual indv : groupWithoutSeeker) {
            float newDistance = seeker.getCoord().calculateDistance(indv.getCoord());
            // 只有在距離較大才換，相當距離時會保證最小編號
            if (newDistance > largestDistance) {
                bestMatcher = indv;
                largestDistance = newDistance;
            }
        }
        return bestMatcher;
    }
}
