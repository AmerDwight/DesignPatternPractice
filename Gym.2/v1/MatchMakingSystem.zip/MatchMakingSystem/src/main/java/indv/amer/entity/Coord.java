package indv.amer.entity;

import java.util.Objects;

public class Coord {
    private int x;
    private int y;

    /**
     * Constructor for Coord class.
     *
     * @param x The x-coordinate.
     * @param y The y-coordinate.
     */
    public Coord(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Coord coord = (Coord) obj;
        return x == coord.x && y == coord.y;
    }

    @Override
    public int hashCode() {
        return Objects.hash(x, y);
    }

    /**
     * Calculates the Euclidean distance between this Coord and another Coord.
     *
     * @param otherCoord The other Coord object to calculate distance to.
     * @return The Euclidean distance as a float.
     */
    public float calculateDistance(Coord otherCoord) {
        if (otherCoord == null) {
            throw new IllegalArgumentException("The other Coord cannot be null.");
        }

        int xDiff = otherCoord.getX() - this.x;
        int yDiff = otherCoord.getY() - this.y;

        // Calculate distance using Euclidean distance formula: sqrt((x2-x1)^2 + (y2-y1)^2)
        return (float) Math.sqrt(Math.pow(xDiff, 2) + Math.pow(yDiff, 2));
    }
}