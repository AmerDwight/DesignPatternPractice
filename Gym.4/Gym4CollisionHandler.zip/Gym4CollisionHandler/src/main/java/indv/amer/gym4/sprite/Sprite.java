package indv.amer.gym4.sprite;

public interface Sprite {
    String getSymbol();
}
