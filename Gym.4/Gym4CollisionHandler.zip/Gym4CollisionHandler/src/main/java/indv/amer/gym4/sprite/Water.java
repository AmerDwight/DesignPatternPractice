package indv.amer.gym4.sprite;

public class Water implements Sprite{
    @Override
    public String getSymbol() {
        return "W";
    }
}
