package indv.amer.gym4.sprite;

public class Fire implements Sprite {
    @Override
    public String getSymbol() {
        return "F";
    }
}
