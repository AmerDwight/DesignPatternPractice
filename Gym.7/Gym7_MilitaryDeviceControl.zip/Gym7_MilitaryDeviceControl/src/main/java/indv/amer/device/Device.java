package indv.amer.device;

public interface Device {
}
