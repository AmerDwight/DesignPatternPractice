package game.component.card;

public interface Card {
}
