package indv.amer.command;

public interface CommandReader {
    String getNextCommand();
}
